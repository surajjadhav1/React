import React from 'react'
import Containt from './Containt'

export default function App() {
  return (
    <div>
      <Containt/>
    </div>
  )
}
