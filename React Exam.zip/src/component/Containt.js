import React from 'react'
import Category from './Category'


export default function Containt() {
  return (
    <div className='container'>
      <h1 className='text-center'>All Products</h1><hr/>
            <Category/>
    </div>
  )
}
